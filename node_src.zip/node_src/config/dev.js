module.exports = {
  googleClientID:
    "625011344981-u61c47ss55nhhprh818njbl22o583nl6.apps.googleusercontent.com",
  googleClientSecret: "XSkV-c3y95vYWLkt7laHWGvL",
  fbClientID: "406407500189347",
  fbClientSecret: "7da62e60cd19b83230ebbe24f0da6efc",
  cookieKey: "erdshgerhknjerhkwetx",
  user: "byan",
  password: "asdf",
  dbName: "mindpouch",
};
